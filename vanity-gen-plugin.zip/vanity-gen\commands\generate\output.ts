import { z } from 'zod';

export const VanityGenOutputSchema = z.object({
    privateKey: z.string().describe('The generated private key'),
    publicKey: z.string().describe('The generated public key'),
    evmAddress: z.string().optional().describe('The EVM address (for ECDSA keys)'),
    attempts: z.number().describe('Number of keys checked'),
    durationMs: z.number().describe('Time taken in milliseconds'),
});

export const VANITY_GEN_TEMPLATE = `
🎉 FOUND VANITY KEY!
   Prefix: {{prefix}}
   
   🔑 Private Key: {{privateKey}}
   🏷️  Public Key:  {{publicKey}}
   {{#if evmAddress}}💎 EVM Address: {{evmAddress}}{{/if}}
   
   Stats:
   - Attempts: {{attempts}}
   - Time: {{durationMs}}ms
`.trim();
