import { CommandHandlerArgs } from '../../../../core/plugins/plugin.interface';
import { CommandExecutionResult } from '../../../../core/plugins/plugin.types';
import { Status } from '../../../../core/shared/constants';
import { VanityGenInputSchema } from './input';
import { VanityGenOutputSchema } from './output';
import { PrivateKey } from '@hashgraph/sdk';

export async function generateHandler(
    args: CommandHandlerArgs,
): Promise<CommandExecutionResult> {
    const { logger } = args;

    // Validate input
    const validArgs = VanityGenInputSchema.parse(args.args);

    logger.info(`🔍 Hunting for prefix: '${validArgs.prefix}' (Type: ${validArgs.keyType})`);
    logger.info('Please wait... this may take a while depending on length.');

    let attempts = 0;
    const startTime = Date.now();
    const target = validArgs.caseSensitive ? validArgs.prefix : validArgs.prefix.toLowerCase();

    let foundKey: PrivateKey | null = null;
    let publicKeyStr = '';
    let evmAddress = '';

    try {
        // Brute Force Loop
        // We break iteration into chunks if we wanted to be async-friendly, but for CLI raw speed is better.
        // 100k attempts limit for safety? No, user wants to hunt.
        // We'll just run.

        while (!foundKey) {
            attempts++;

            let key: PrivateKey;
            if (validArgs.keyType === 'ECDSA') {
                key = PrivateKey.generateECDSA();
            } else {
                key = PrivateKey.generateED25519();
            }

            if (validArgs.keyType === 'ECDSA') {
                const evm = key.publicKey.toEvmAddress(); // "0x..."

                // Check
                const checkStr = validArgs.caseSensitive ? evm : evm.toLowerCase();
                // Allow matching "starts with 0x" + prefix or just "starts with"
                // Usually EVM starts with 0x. If user typed 'abc', we check matching.

                if (checkStr.startsWith(target) || (target.startsWith('0x') && checkStr.startsWith(target)) || checkStr.startsWith('0x' + target)) {
                    foundKey = key;
                    publicKeyStr = key.publicKey.toStringDer();
                    evmAddress = evm;
                }
            } else {
                const pub = key.publicKey.toStringDer();
                const checkStr = validArgs.caseSensitive ? pub : pub.toLowerCase();
                if (checkStr.startsWith(target)) {
                    foundKey = key;
                    publicKeyStr = pub;
                }
            }

            // Log every 5000
            if (attempts % 5000 === 0) {
                // We can't easily overwrite line in this logger, so we just wait.
                // logger.debug(`Checked ${attempts}...`); 
            }
        }

        const duration = Date.now() - startTime;
        logger.info(`✅ MATCH FOUND after ${attempts} attempts!`);

        const output = VanityGenOutputSchema.parse({
            privateKey: foundKey.toStringDer(),
            publicKey: publicKeyStr,
            evmAddress: evmAddress || undefined,
            attempts: attempts,
            durationMs: duration,
        });

        return {
            status: Status.Success,
            outputJson: JSON.stringify({ ...output, prefix: validArgs.prefix }), // Add prefix for template
        };
    } catch (error) {
        return {
            status: Status.Failure,
            errorMessage: `Failed generation: ${String(error)}`
        };
    }
}
