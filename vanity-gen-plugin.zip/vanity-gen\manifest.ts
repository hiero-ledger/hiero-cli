import { PluginManifest } from '../../core/plugins/plugin.interface';
import { generateCommand } from './commands/generate';

export const vanityGenManifest: PluginManifest = {
    name: 'vanity-gen',
    version: '1.0.0',
    displayName: 'Vanity Address Generator',
    description: 'Generate custom Hedera/EVM addresses with user-defined prefixes',
    commands: [generateCommand],
};

export default vanityGenManifest;
