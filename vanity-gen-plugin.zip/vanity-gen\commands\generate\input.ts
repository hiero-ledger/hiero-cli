import { z } from 'zod';

/**
 * Input schema for vanity key generation
 */
export const VanityGenInputSchema = z.object({
    prefix: z
        .string()
        .min(1, 'Prefix is required')
        .regex(/^[0-9a-fA-F]+$/, 'Prefix must be hex characters (0-9, a-f)'),

    keyType: z
        .enum(['ED25519', 'ECDSA'])
        .default('ED25519')
        .describe('Key type to generate (ED25519 or ECDSA)'),

    caseSensitive: z
        .boolean()
        .default(false)
        .describe('Match exact case sensitive prefix'),
});

export type VanityGenInput = z.infer<typeof VanityGenInputSchema>;
