import { CommandSpec } from '../../../../core/plugins/plugin.interface';
import { generateHandler } from './handler';
import { VanityGenOutputSchema, VANITY_GEN_TEMPLATE } from './output';

export const generateCommand: CommandSpec = {
    name: 'generate',
    summary: 'Generate a vanity address',
    description: 'Brute-force generate a private key with a specific public key prefix',
    options: [
        {
            name: 'prefix',
            short: 'p',
            type: 'string',
            required: true,
            description: 'The hex prefix to search for (e.g. abc)'
        },
        {
            name: 'key-type',
            short: 't',
            type: 'string',
            required: false,
            default: 'ED25519',
            description: 'Key Algorithm (ED25519 or ECDSA)'
        },
        {
            name: 'case-sensitive',
            short: 'c',
            type: 'boolean',
            required: false,
            default: false,
            description: 'Match exact case'
        }
    ],
    handler: generateHandler,
    output: {
        schema: VanityGenOutputSchema,
        humanTemplate: VANITY_GEN_TEMPLATE,
    },
};
